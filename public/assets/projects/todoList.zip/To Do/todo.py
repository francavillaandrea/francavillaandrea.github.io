import tkinter as tk
from tkinter import messagebox
import json
import os

TODO_FILE = "todo.json"

def load_tasks():
    if os.path.exists(TODO_FILE):
        try:
            with open(TODO_FILE, "r") as f:
                content = f.read().strip()
                return json.loads(content) if content else []
        except json.JSONDecodeError:
            messagebox.showwarning("Errore file", "Il file dei task è corrotto. Verrà ripristinato.")
            return []
    return []

def save_tasks(tasks):
    with open(TODO_FILE, "w") as f:
        json.dump(tasks, f, indent=4)

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")
        self.tasks = load_tasks()

        # Entry per nuova attività
        self.entry = tk.Entry(root, width=50)
        self.entry.pack(pady=5)

        # Pulsanti
        tk.Button(root, text="Aggiungi", command=self.add_task).pack(pady=2)
        tk.Button(root, text="Completa", command=self.complete_task).pack(pady=2)
        tk.Button(root, text="Rimuovi", command=self.remove_task).pack(pady=2)
        tk.Button(root, text="Resetta Tutto", command=self.reset_all).pack(pady=10)

        # Lista attività
        self.listbox = tk.Listbox(root, width=60, height=10)
        self.listbox.pack(pady=10)

        self.refresh()

    def refresh(self):
        self.listbox.delete(0, tk.END)
        for task in self.tasks:
            status = "✓" if task["done"] else " "
            self.listbox.insert(tk.END, f"[{status}] {task['desc']}")

    def add_task(self):
        desc = self.entry.get().strip()
        if desc:
            self.tasks.append({"desc": desc, "done": False})
            self.entry.delete(0, tk.END)
            self.refresh()
            save_tasks(self.tasks)
        else:
            messagebox.showwarning("Input mancante", "Inserisci una descrizione per il task.")

    def complete_task(self):
        selected = self.listbox.curselection()
        if selected:
            index = selected[0]
            self.tasks[index]["done"] = True
            self.refresh()
            save_tasks(self.tasks)
        else:
            messagebox.showinfo("Nessuna selezione", "Seleziona un task da completare.")

    def remove_task(self):
        selected = self.listbox.curselection()
        if selected:
            index = selected[0]
            del self.tasks[index]
            self.refresh()
            save_tasks(self.tasks)
        else:
            messagebox.showinfo("Nessuna selezione", "Seleziona un task da rimuovere.")

    def reset_all(self):
        if messagebox.askyesno("Conferma", "Vuoi cancellare tutti i task?"):
            self.tasks = []
            save_tasks(self.tasks)
            self.refresh()

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
